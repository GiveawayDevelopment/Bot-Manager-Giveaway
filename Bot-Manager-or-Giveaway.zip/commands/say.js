exports.run = (client, message, args) => {
 let toSay = args.join(" ") 
 if (!toSay) return message.channel.send({content: "You have to provide a message"})
 message.channel.send(content: toSay)
}